package com.moneyflow.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.moneyflow.app.ui.theme.*
import com.moneyflow.app.ui.viewmodel.DashboardViewModel
import com.moneyflow.app.ui.viewmodel.ProjectSummary
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigateToProjects: () -> Unit,
    onNavigateToProjectDetail: (Long) -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val summaries by viewModel.projectSummaries.collectAsState()
    val totalIncome by viewModel.totalIncome.collectAsState()
    val totalExpense by viewModel.totalExpense.collectAsState()
    val netProfit by viewModel.netProfit.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MoneyFlow", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Blue700,
                    titleContentColor = CardBackground
                ),
                actions = {
                    IconButton(onClick = onNavigateToAbout) {
                        Icon(Icons.Default.Info, contentDescription = "About", tint = CardBackground)
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNavigateToProjects,
                icon = { Icon(Icons.Default.Folder, contentDescription = null) },
                text = { Text("Projects") },
                containerColor = Blue700,
                contentColor = CardBackground
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                OverallSummaryCard(totalIncome, totalExpense, netProfit)
            }

            item {
                Text(
                    text = "Projects Overview",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            if (summaries.isEmpty()) {
                item { EmptyProjectsState(onNavigateToProjects) }
            } else {
                items(summaries) { summary ->
                    ProjectSummaryCard(summary, onClick = { onNavigateToProjectDetail(summary.project.id) })
                }
            }

            item { Spacer(modifier = Modifier.height(80.dp)) }
        }
    }
}

@Composable
private fun OverallSummaryCard(income: Double, expense: Double, net: Double) {
    val fmt = NumberFormat.getNumberInstance(Locale.getDefault()).apply { maximumFractionDigits = 2 }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Blue700),
        shape = MaterialTheme.shapes.large
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Overall Summary", color = CardBackground.copy(alpha = 0.8f),
                style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            Text(
                text = "৳ ${fmt.format(net)}",
                color = if (net >= 0) Green100 else Red100,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (net >= 0) "Net Profit" else "Net Loss",
                color = CardBackground.copy(alpha = 0.7f),
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                SummaryItem("Income", income, Green100, fmt)
                SummaryItem("Expense", expense, Red100, fmt)
            }
        }
    }
}

@Composable
private fun SummaryItem(label: String, amount: Double, color: androidx.compose.ui.graphics.Color, fmt: NumberFormat) {
    Column {
        Text(label, color = CardBackground.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
        Text("৳ ${fmt.format(amount)}", color = color, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ProjectSummaryCard(summary: ProjectSummary, onClick: () -> Unit) {
    val fmt = NumberFormat.getNumberInstance(Locale.getDefault()).apply { maximumFractionDigits = 2 }
    val net = summary.netProfit
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(summary.project.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (summary.project.description.isNotBlank()) {
                    Text(summary.project.description, style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary, maxLines = 1)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("↑ ৳${fmt.format(summary.totalIncome)}", color = Green700,
                        style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                    Text("↓ ৳${fmt.format(summary.totalExpense)}", color = Red700,
                        style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "৳${fmt.format(net)}",
                    color = if (net >= 0) Green700 else Red700,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    if (net >= 0) "Profit" else "Loss",
                    color = if (net >= 0) Green700 else Red700,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun EmptyProjectsState(onAdd: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Blue50)
    ) {
        Column(
            modifier = Modifier.padding(32.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.FolderOpen, contentDescription = null,
                modifier = Modifier.size(48.dp), tint = Blue700)
            Spacer(Modifier.height(12.dp))
            Text("No projects yet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("Create your first project to start tracking finances.",
                style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Spacer(Modifier.height(16.dp))
            Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Blue700)) {
                Text("Add Project")
            }
        }
    }
}
