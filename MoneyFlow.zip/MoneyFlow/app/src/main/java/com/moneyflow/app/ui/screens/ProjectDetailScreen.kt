package com.moneyflow.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.moneyflow.app.data.Transaction
import com.moneyflow.app.data.TransactionType
import com.moneyflow.app.ui.theme.*
import com.moneyflow.app.ui.viewmodel.ProjectViewModel
import com.moneyflow.app.ui.viewmodel.TransactionViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailScreen(
    projectId: Long,
    projectViewModel: ProjectViewModel,
    transactionViewModel: TransactionViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToAddTransaction: () -> Unit,
    onNavigateToEditTransaction: (Long) -> Unit
) {
    val projects by projectViewModel.projects.collectAsState()
    val project = projects.find { it.id == projectId }
    val transactions by transactionViewModel.transactions.collectAsState()
    val totalIncome by transactionViewModel.totalIncome.collectAsState()
    val totalExpense by transactionViewModel.totalExpense.collectAsState()
    val netProfit by transactionViewModel.netProfit.collectAsState()
    var showDeleteDialog by remember { mutableStateOf<Transaction?>(null) }

    val fmt = NumberFormat.getNumberInstance(Locale.getDefault()).apply { maximumFractionDigits = 2 }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(project?.name ?: "Project", fontWeight = FontWeight.Bold, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = CardBackground)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Blue700,
                    titleContentColor = CardBackground
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToAddTransaction,
                containerColor = Blue700,
                contentColor = CardBackground
            ) {
                Icon(Icons.Default.Add, "Add Transaction")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                ProjectFinanceSummaryCard(totalIncome, totalExpense, netProfit, fmt)
            }

            item {
                Text("Transactions", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 4.dp))
            }

            if (transactions.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Blue50)
                    ) {
                        Column(
                            modifier = Modifier.padding(32.dp).fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.ReceiptLong, null, Modifier.size(48.dp), tint = Blue700.copy(0.5f))
                            Spacer(Modifier.height(8.dp))
                            Text("No transactions yet", color = TextSecondary)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = onNavigateToAddTransaction,
                                colors = ButtonDefaults.buttonColors(containerColor = Blue700)) {
                                Text("Add Transaction")
                            }
                        }
                    }
                }
            } else {
                items(transactions) { tx ->
                    TransactionItem(
                        transaction = tx,
                        fmt = fmt,
                        onEdit = { onNavigateToEditTransaction(tx.id) },
                        onDelete = { showDeleteDialog = tx }
                    )
                }
            }

            item { Spacer(Modifier.height(80.dp)) }
        }
    }

    showDeleteDialog?.let { tx ->
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text("Delete Transaction") },
            text = { Text("Delete \"${tx.title}\"?") },
            confirmButton = {
                TextButton(onClick = {
                    transactionViewModel.deleteTransaction(tx)
                    showDeleteDialog = null
                }) { Text("Delete", color = Red700) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ProjectFinanceSummaryCard(income: Double, expense: Double, net: Double, fmt: NumberFormat) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Blue700),
        shape = MaterialTheme.shapes.large
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Project Summary", color = CardBackground.copy(0.8f), style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            Text(
                "৳ ${fmt.format(net)}",
                color = if (net >= 0) Green100 else Red100,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text(if (net >= 0) "Net Profit" else "Net Loss", color = CardBackground.copy(0.7f),
                style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Total Income", color = CardBackground.copy(0.7f), style = MaterialTheme.typography.bodySmall)
                    Text("৳${fmt.format(income)}", color = Green100,
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Total Expense", color = CardBackground.copy(0.7f), style = MaterialTheme.typography.bodySmall)
                    Text("৳${fmt.format(expense)}", color = Red100,
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun TransactionItem(
    transaction: Transaction,
    fmt: NumberFormat,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isIncome = transaction.type == TransactionType.INCOME
    val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(transaction.createdAt))

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = MaterialTheme.shapes.small,
                color = if (isIncome) Green100 else Red100,
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        if (isIncome) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                        null,
                        tint = if (isIncome) Green700 else Red700,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(transaction.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                if (transaction.note.isNotBlank()) {
                    Text(transaction.note, style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 1)
                }
                Text(dateStr, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "${if (isIncome) "+" else "-"}৳${fmt.format(transaction.amount)}",
                    color = if (isIncome) Green700 else Red700,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            Column {
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Edit, "Edit", tint = Blue700, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, "Delete", tint = Red700, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
