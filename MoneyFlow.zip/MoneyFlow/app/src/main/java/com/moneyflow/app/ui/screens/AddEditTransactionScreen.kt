package com.moneyflow.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.moneyflow.app.data.TransactionType
import com.moneyflow.app.ui.theme.*
import com.moneyflow.app.ui.viewmodel.TransactionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTransactionScreen(
    projectId: Long,
    transactionId: Long?,
    viewModel: TransactionViewModel,
    onNavigateBack: () -> Unit
) {
    val isEditing = transactionId != null
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(TransactionType.INCOME) }
    var note by remember { mutableStateOf("") }
    var titleError by remember { mutableStateOf(false) }
    var amountError by remember { mutableStateOf(false) }

    LaunchedEffect(transactionId) {
        if (transactionId != null) {
            viewModel.getTransactionById(transactionId)?.let { tx ->
                title = tx.title
                amount = tx.amount.toString()
                selectedType = tx.type
                note = tx.note
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Edit Transaction" else "Add Transaction", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = CardBackground)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Blue700,
                    titleContentColor = CardBackground
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            // Transaction type selector
            Text("Transaction Type", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TypeButton(
                    label = "Income",
                    icon = Icons.Default.TrendingUp,
                    selected = selectedType == TransactionType.INCOME,
                    selectedColor = Green700,
                    modifier = Modifier.weight(1f),
                    onClick = { selectedType = TransactionType.INCOME }
                )
                TypeButton(
                    label = "Expense",
                    icon = Icons.Default.TrendingDown,
                    selected = selectedType == TransactionType.EXPENSE,
                    selectedColor = Red700,
                    modifier = Modifier.weight(1f),
                    onClick = { selectedType = TransactionType.EXPENSE }
                )
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it; titleError = false },
                label = { Text("Title *") },
                isError = titleError,
                supportingText = if (titleError) ({ Text("Title is required") }) else null,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                leadingIcon = { Icon(Icons.Default.Label, null, tint = Blue700) }
            )

            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it; amountError = false },
                label = { Text("Amount (৳) *") },
                isError = amountError,
                supportingText = if (amountError) ({ Text("Enter a valid amount") }) else null,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
                leadingIcon = { Icon(Icons.Default.CurrencyExchange, null, tint = Blue700) }
            )

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Note (optional)") },
                modifier = Modifier.fillMaxWidth().height(100.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                leadingIcon = { Icon(Icons.Default.Notes, null, tint = Blue700) }
            )

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = {
                    val amountVal = amount.toDoubleOrNull()
                    titleError = title.isBlank()
                    amountError = amountVal == null || amountVal <= 0
                    if (titleError || amountError) return@Button

                    if (isEditing) {
                        viewModel.getTransactionById(transactionId!!)?.let { tx ->
                            viewModel.updateTransaction(tx, title.trim(), amountVal!!, selectedType, note.trim())
                        }
                    } else {
                        viewModel.addTransaction(title.trim(), amountVal!!, selectedType, note.trim())
                    }
                    onNavigateBack()
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedType == TransactionType.INCOME) Green700 else Red700
                )
            ) {
                Icon(if (isEditing) Icons.Default.Save else Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text(if (isEditing) "Save Changes" else "Add Transaction", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
private fun TypeButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    selectedColor: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val containerColor = if (selected) selectedColor else SurfaceLight
    val contentColor = if (selected) CardBackground else TextSecondary

    Button(
        onClick = onClick,
        modifier = modifier.height(52.dp),
        colors = ButtonDefaults.buttonColors(containerColor = containerColor, contentColor = contentColor),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = if (selected) 4.dp else 0.dp)
    ) {
        Icon(icon, null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}
