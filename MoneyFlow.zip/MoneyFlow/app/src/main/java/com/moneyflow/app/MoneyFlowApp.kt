package com.moneyflow.app

import android.app.Application
import androidx.room.Room
import com.moneyflow.app.data.AppDatabase

class MoneyFlowApp : Application() {
    val database: AppDatabase by lazy {
        Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "moneyflow.db"
        ).fallbackToDestructiveMigration().build()
    }
}
