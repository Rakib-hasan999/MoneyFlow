# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in proguard-android.txt
-keepattributes *Annotation*
-keep class com.moneyflow.app.data.** { *; }
